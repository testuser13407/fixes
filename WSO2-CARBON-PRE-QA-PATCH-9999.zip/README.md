WSO2 Identity Server Version 5.8.0
Hazelcast revision:  v3.5.4
Binary file: repository/components/plugins/hazelcast_3.5.4.wso2v2.jar
Instructions: Copy the "patch9999" directory to <IS-HOME>/repository/components/patches directory and restart the server.
#Patch diff can be found in the same directory as this file.
